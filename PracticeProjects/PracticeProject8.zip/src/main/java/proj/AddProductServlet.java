package proj;
import javax.servlet.http.*;

import javax.servlet.*;
import java.io.*;
import org.hibernate.*;
import org.hibernate.cfg.*;

public class AddProductServlet extends HttpServlet {

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       PrintWriter out = response.getWriter();
      String name = request.getParameter("name");
      String description = request.getParameter("description");
  	RequestDispatcher rd=null;
          Double price = Double.parseDouble(request.getParameter("price"));
    
      Product product = new Product();
      product.setName(name);
      product.setDescription(description);
      product.setPrice(price);

      
      Configuration cfg = new Configuration();
      cfg.configure("hibernate.cfg.xml");

      SessionFactory factory = cfg.buildSessionFactory();
      Session session = factory.openSession();
      Transaction tx = session.beginTransaction();
      session.save(product);
      tx.commit();

      session.close();
      factory.close();
   	
  	rd=request.getRequestDispatcher("addProduct.jsp");
		rd.include(request, response);
	
      out.println("<center><span style='color:blue"
				+ "'>Product added successfully</span></center>");

   }
}