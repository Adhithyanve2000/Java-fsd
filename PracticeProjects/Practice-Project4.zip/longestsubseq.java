package longestsubsequence;


	import java.util.ArrayList;
	import java.util.List;
	import java.util.Scanner;

	public class longestsubseq {
	    public static List<Integer> findLongestIncreasingSubsequence(int[] nums) {
	        if (nums == null || nums.length == 0) {
	            return new ArrayList<>();
	        }

	        int[] dp = new int[nums.length];
	        int[] prevIndices = new int[nums.length];
	        java.util.Arrays.fill(prevIndices, -1);

	        int maxLength = 1;
	        int endIndex = 0;

	        for (int i = 1; i < nums.length; i++) {
	            for (int j = 0; j < i; j++) {
	                if (nums[i] > nums[j] && dp[i] < dp[j] + 1) {
	                    dp[i] = dp[j] + 1;
	                    prevIndices[i] = j;
	                    if (dp[i] > maxLength) {
	                        maxLength = dp[i];
	                        endIndex = i;
	                    }
	                }
	            }
	        }

	        List<Integer> longestIncreasingSubsequence = new ArrayList<>();
	        while (endIndex >= 0) {
	            longestIncreasingSubsequence.add(0, nums[endIndex]);
	            endIndex = prevIndices[endIndex];
	        }

	        return longestIncreasingSubsequence;
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter the number of elements: ");
	        int n = scanner.nextInt();

	        int[] nums = new int[n];
	        System.out.println("Enter the elements:");
	        for (int i = 0; i < n; i++) {
	            nums[i] = scanner.nextInt();
	        }

	        List<Integer> longestIncreasingSubsequence = findLongestIncreasingSubsequence(nums);
	        System.out.println("Longest Increasing Subsequence: " + longestIncreasingSubsequence);

	        scanner.close();
	    }
	}

