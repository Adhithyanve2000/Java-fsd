package AssistedProject2;
import java.util.*;

public class Verificationemail {

		
	  public static void main(String[] args) {
	    // Define a List of email IDs
	    List<String> emailIDs = new ArrayList<>();
	    emailIDs.add("adhi.ve@example.com");
	    emailIDs.add("maathu.doe@example.com");
	    emailIDs.add("athul.791@example.com");

	    // Get the email ID to search from the user
	    Scanner scanner = new Scanner(System.in);
	    System.out.print("Enter an email ID to search: ");
	    String searchEmailID = scanner.nextLine();

	    // Search for the email ID in the List
	    boolean found = emailIDs.contains(searchEmailID);

	   
	    if (found) {
	      System.out.println("Email ID found in the List.");
	    } else {
	      System.out.println("Email ID not found in the List.");
	    }
	}
	}


