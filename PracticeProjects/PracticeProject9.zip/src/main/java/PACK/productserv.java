package PACK;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class productserv extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   
        String name = request.getParameter("name");
        double price = Double.parseDouble(request.getParameter("price"));
        String description = request.getParameter("description");

     
        product product1 = new product();
        product1.setName(name);
        product1.setPrice(price);
        product1.setDescription(description);


        request.getSession().setAttribute("product1", product1);

      
        response.sendRedirect("displayProject.jsp");
    }
}
