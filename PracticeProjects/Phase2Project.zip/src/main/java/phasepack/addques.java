package phasepack;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class addques extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String text = request.getParameter("question");
        String a1 = request.getParameter("a1");
        String b1 = request.getParameter("b1");
        String c1 = request.getParameter("c1");
        String d1 = request.getParameter("d1");
        String corr = request.getParameter("answer");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce", "root", "Agent047");

            PreparedStatement ps = conn.prepareStatement("INSERT INTO Questionss (Text, A1, B1, C1, D1, corr) VALUES (?, ?, ?, ?, ?, ?)");
            ps.setString(1, text);
            ps.setString(2, a1);
            ps.setString(3, b1);
            ps.setString(4, c1);
            ps.setString(5, d1);
            ps.setString(6, corr);

            ps.executeUpdate();
            request.setAttribute("questionAdded", true);
     
            response.sendRedirect("admin.jsp");

            conn.close();
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}