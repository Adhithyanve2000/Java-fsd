package phasepack;

import java.io.IOException;


import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.PrintWriter;


public class Profpage extends HttpServlet {
	

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        String username = request.getParameter("newUsername");
        String password = request.getParameter("newPassword"); 
        String password1 = request.getParameter("confirmPassword"); 
        String type="Normal";
      
        try{
        RequestDispatcher rd=null;
        PrintWriter out = response.getWriter();
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce", "root", "Agent047");
        if(password1.equals(password)) {
PreparedStatement ps1 = conn.prepareStatement("INSERT INTO Users (Username, Password, Type) VALUES (?, ?, ?)");
                ps1.setString(1, username);
                ps1.setString(2, password);
                ps1.setString(3, type);
                ps1.executeUpdate();
             	rd=request.getRequestDispatcher("logform.jsp");
        		rd.include(request, response);
        	
               out.println("<center><span style='color:blue"
        				+ "'>user added successfully</span></center>");
        }        
        else
        {
        	rd=request.getRequestDispatcher("logform.jsp");
    		rd.include(request, response);
    	
           out.println("<center><span style='color:blue"
    				+ "'>password not correct successfully</span></center>");
        }
    } catch(Exception e) {
        e.printStackTrace();
    }
    }
}