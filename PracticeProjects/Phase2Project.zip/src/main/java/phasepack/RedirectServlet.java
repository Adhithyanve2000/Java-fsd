package phasepack;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



	
	/**
	 * Servlet implementation class RedirectServlet
	 */
	public class RedirectServlet extends HttpServlet {
		private static final long serialVersionUID = 1L;
	       
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		    String redirectOption = request.getParameter("redirectOption");
		    
		    if (redirectOption.equals("View User Profile")) {
		        response.sendRedirect("user.jsp");
		    } else if (redirectOption.equals("Show Leaderboard")) {
		       String score = request.getParameter("score");
		       request.getSession().setAttribute("score", score);
		       System.out.println("Score: " + score);
		        response.sendRedirect("leaderboard.jsp?score=" + score);
		    }
		}
	}



