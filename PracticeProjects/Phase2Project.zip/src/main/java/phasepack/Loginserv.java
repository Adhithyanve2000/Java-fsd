package phasepack;

import java.io.IOException;



import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.PrintWriter;


public class Loginserv extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        String username = request.getParameter("username");
        String password = request.getParameter("password"); 
        String type="Normal";
   
        String dbPassword = null;
        String dbType = null;
        int  dbid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce", "root", "Agent047");
        	RequestDispatcher rd=null;
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Users WHERE Username = ?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
          
       
            if (rs.next()) 
            {
           
           
                dbPassword = rs.getString("Password");
                dbType = rs.getString("Type");
                dbid=rs.getInt("ID");
                request.getSession().setAttribute("UserID", dbid);
            }

            
            if (password.equals(dbPassword)) {
                if ("Admin".equals(dbType)) {
                    response.sendRedirect("admin.jsp");
                } else if ("Normal".equals(dbType)) {
                    response.sendRedirect("user.jsp");
                }else {
                    // Incorrect credentials
                    request.setAttribute("errorMessage", "Incorrect Credentials");
                    rd = request.getRequestDispatcher("logform.jsp");
                    rd.forward(request, response);
                }}else {
                    // Incorrect credentials
                    request.setAttribute("errorMessage", "Incorrect Credentials");
                    rd = request.getRequestDispatcher("logform.jsp");
                    rd.forward(request, response);
                }
             
          
            conn.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}