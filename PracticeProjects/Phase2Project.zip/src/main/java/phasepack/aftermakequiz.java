package phasepack;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class aftermakequiz extends HttpServlet {
	static int counter = 1;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the quiz name and selected question IDs from the request parameters
        String quizName = request.getParameter("quizName");
        String[] selectedQuestions = request.getParameterValues("selectedQuestions[]");

        // Database connection details
        String url = "jdbc:mysql://localhost:3306/ecommerce";
        String username = "root";
        String password = "Agent047";
        
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
 
        	   conn = DriverManager.getConnection(url, username, password);
      
            String insertQuery = "INSERT INTO Quizzess (QuizID, Name, ID) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(insertQuery);

            if (selectedQuestions != null && selectedQuestions.length > 0) {
                // Step 4: Set parameters and execute the SQL statement for each selected question ID
                for (String questionID : selectedQuestions) {
                    stmt.setInt(1, counter);
                    stmt.setString(2, quizName);
                    stmt.setString(3, questionID);
                    stmt.executeUpdate();
                }
            }
            counter++;
            // Quiz creation successful
            request.setAttribute("quizCreated", true);
            // Redirect to the admin.jsp page
            response.sendRedirect("admin.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Step 6: Close the database connection and resources
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
