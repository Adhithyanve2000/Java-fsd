package phasepack;
import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;



public class AnswerCheckServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String url = "jdbc:mysql://localhost:3306/ecommerce";
        String username = "root";
        String password = "Agent047";
        String quizIDStr = request.getParameter("quizId");
        int quizID = Integer.parseInt(quizIDStr);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, username, password);
            PreparedStatement stmt = null;
            ResultSet rs = null;

            List<Integer> idList = new ArrayList<>();

            String idQuery = "SELECT ID FROM Quizzess WHERE QuizID = ?";
            stmt = conn.prepareStatement(idQuery);
            stmt.setInt(1, quizID);
            rs = stmt.executeQuery();
       
            while (rs.next()) {
                int id = rs.getInt("ID");
                idList.add(id);
            }

            int score = 0; // Initialize the score variable
            Map<Integer, String> correctAnswersMap = new HashMap<>();
            for (int id : idList) {
                String userAnswer = request.getParameter("answer" + id);
                String correctAnswer = request.getParameter("correctAnswer" + id);
                System.out.println("User Answer for question " + id + ": " + userAnswer);
                System.out.println("Correct Answer for question " + id + ": " + correctAnswer);
                correctAnswersMap.put(id, correctAnswer);
                if (correctAnswer.equals(userAnswer)) {
                    score++; // Increase the score if the answer is correct
                }
            }
            request.setAttribute("correctAnswersMap", correctAnswersMap);
            if (rs != null) { rs.close(); }
            if (stmt != null) { stmt.close(); }
            if (conn != null) { conn.close(); }

            // Store the score in the database
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.prepareStatement("INSERT INTO QuizScores2 (ID,QuizID,Score) VALUES (?,?, ?)");

                
                	int dbid = (int) request.getSession().getAttribute("UserID");
                	stmt.setInt(1, dbid);
                    stmt.setInt(2, quizID);
                    stmt.setInt(3, score);
                    
                    stmt.executeUpdate();
                

                stmt.close();
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            request.setAttribute("score", score);
            request.getRequestDispatcher("QuizResults.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }}