package phasepack;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class newpassw extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String oldPassword = request.getParameter("oldPassword");
        String newPassword = request.getParameter("newPassword");
        RequestDispatcher rd=null;
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce", "root", "Agent047");

            PreparedStatement verifyPs = conn.prepareStatement("SELECT password FROM users WHERE username = ?");
            verifyPs.setString(1, username);
            ResultSet rs = verifyPs.executeQuery();

            if (rs.next() && rs.getString("password").equals(oldPassword)) {
         
                PreparedStatement updatePs = conn.prepareStatement("UPDATE Users SET password = ? WHERE username = ?");
                updatePs.setString(1, newPassword);
                updatePs.setString(2, username);
                updatePs.executeUpdate();

    
                response.sendRedirect("passwordChangeSuccess.jsp");
            } else {
            	rd=request.getRequestDispatcher("admin.jsp");
        		rd.include(request, response);
        	
               out.println("<center><span style='color:blue"
        				+ "'>user added successfully</span></center>");
            }

            conn.close();
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}