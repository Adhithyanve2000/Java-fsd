package com.example.UserManager.exceptions;

public class UserNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    
    /*
    private final String userId;

    public UserNotFoundException() {
      super();
      this.userId = id;
    }

    public String getUserId() {
      return userId;
    }
    */
}
