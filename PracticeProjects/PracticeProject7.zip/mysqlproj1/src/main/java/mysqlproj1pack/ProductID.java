package mysqlproj1pack;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ProductID extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productId = request.getParameter("productId");
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {

        	   try {
        	        Class.forName("com.mysql.jdbc.Driver");
        	    } catch (ClassNotFoundException e1) {
        	        e1.printStackTrace();
        	    }
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce", "root", "Agent047");

 
            String query = "SELECT * FROM products WHERE id = ?;";
            statement = connection.prepareStatement(query);
            statement.setString(1, productId);
            resultSet = statement.executeQuery();
        	RequestDispatcher rd=null;
            PrintWriter out = response.getWriter();
           

            if (resultSet.next()) {
                String retrievedProductId = resultSet.getString("id");
                if (productId.equals(retrievedProductId)) {
                    HttpSession session = request.getSession();
                    session.setAttribute("productId", retrievedProductId);
                    session.setAttribute("name", resultSet.getString("name"));
                    session.setAttribute("description", resultSet.getString("description"));
                    session.setAttribute("price", resultSet.getDouble("price"));

                    response.sendRedirect("Displaydetails");
                } 
            }
            	
            	rd=request.getRequestDispatcher("ProductFile.html");
    			rd.include(request, response);
    			out.println("<center><span style='color:blue"
    					+ "'>Incorrect ID</span></center>");
            
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}