package mysqlproj1pack;
import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

public class Displaydetails extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
    

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
         
        	String productId = (String) session.getAttribute("productId");
            String name = (String) session.getAttribute("name");
            String description = (String) session.getAttribute("description");
            double price = (Double) session.getAttribute("price");
            out.println("<style>");
            out.println("h1 { color: blue; }");
            out.println("p { font-family: Arial, sans-serif; }");
            out.println("b { font-weight: bold; }");
            out.println(".price { color: green; font-size: 18px; }");
            out.println("</style>");

            out.println("<h1>Product Details</h1>");
            out.println("<p><b>Product ID:</b> " + productId + "</p>");
            out.println("<p><b>Name:</b> " + name + "</p>");
            out.println("<p><b>Description:</b> " + description + "</p>");
            out.println("<p class=\"price\"><b>Price:</b> $" + price + "</p>");
          
           
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}