import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class QuizService {
  constructor(private http: HttpClient) {}

  get(url: string) {
    return this.http.get(url);
  }

  getAll() {
    return [
      {
        id: 'data/filmq.json',
        name: 'Films',
        description:
          "Let's play a films quiz which tests your knowledge in films and contains 10 Questions.",
        imageUrl: 'assets/images/JS.png',
      },
     
      
    ];
  }
}
