package sddsd;


	import java.sql.*;
	public class pracproj {

	    public static void main(String[] args) {
	        String url = "jdbc:mysql://localhost:3306/ecommerce";
	        String user = "root";
	        String password = "Agent047";

	        try (Connection con = DriverManager.getConnection(url, user, password)) {

	            CallableStatement stmt = con.prepareCall("{CALL GetProductPrice(?, ?)}");

	            
	            stmt.setInt(1, 1);  
	            stmt.registerOutParameter(2, java.sql.Types.DECIMAL);

	     
	            stmt.execute();

	            
	            BigDecimal price = stmt.getBigDecimal(2);

	            System.out.println("Product Price: " + price);

	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    }
	}
