package pack;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class projectt {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/ecommerce";
        String user = "username";
        String password = "password";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement()) {

            // Insert a record
            String sql = "INSERT INTO products (product_id, product_name, product_desc, product_price) VALUES (1, 'Product 1', 'Description 1', 99.99)";
            stmt.executeUpdate(sql);
            System.out.println("Inserted record into the table...");

            // Update the record
            sql = "UPDATE products SET product_price = 199.99 WHERE product_id = 1";
            stmt.executeUpdate(sql);
            System.out.println("Updated record in the table...");

            // Delete the record
            sql = "DELETE FROM products WHERE product_id = 1";
            stmt.executeUpdate(sql);
            System.out.println("Deleted record from the table...");

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

