package sas;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class packk {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/testdb"; // replace 'testdb' with your database name
        String user = "root"; // replace with your username
        String password = ""; // replace with your password

        try {
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Successfully connected to the database.");
        } catch (SQLException e) {
            System.out.println("Connecting to the database failed.");
            e.printStackTrace();
        }
    }
}