package AssistedPractice9;

public class Arrayimplementation {
	    public static void main(String[] args) {
	        int[] numbers = new int[5];

	        numbers[0] = 10;
	        
	        numbers[1] = 20;
	        
	        numbers[2] = 30;
	        
	        numbers[3] = 40;
	        
	        numbers[4] = 50;
	        

	        System.out.println("Element at index 0: " + numbers[0]);
	        
	        System.out.println("Element at index 1: " + numbers[1]);
	        
	        System.out.println("Element at index 2: " + numbers[2]);
	        
	        System.out.println("Element at index 3: " + numbers[3]);
	        
	        System.out.println("Element at index 4: " + numbers[4]);

	        String[] names = {"John", "Jane", "Jim", "Jake", "Jill"};

	     
	        System.out.println("Element at index 0: " + names[0]);
	        
	        System.out.println("Element at index 1: " + names[1]);
	        
	        System.out.println("Element at index 2: " + names[2]);
	        
	        System.out.println("Element at index 3: " + names[3]);
	        
	        System.out.println("Element at index 4: " + names[4]);
	    }
	}

