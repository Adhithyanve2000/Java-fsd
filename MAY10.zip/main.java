package hag;

class Bank {
    static double roi;
    
    static double calIntrest(double amount) {
        return roi / 100 * amount;
    }
}

class HDFC extends Bank {
    static {
        roi = 8.5;
    }
}

class ICICI extends Bank {
    static {
        roi = 7.5;
    }
}

// Example usage
public class main {
    public static void main(String[] args) {
        double amount = 10000;
        
        HDFC hdfc = new HDFC();
        double interest = hdfc.calIntrest(amount);
        double finalAmount = amount + interest;
        System.out.println("Final amount in HDFC: " + finalAmount);
        
        ICICI icici = new ICICI();
        interest = icici.calIntrest(amount);
        finalAmount = amount + interest;
        System.out.println("Final amount in ICICI: " + finalAmount);
    }
}