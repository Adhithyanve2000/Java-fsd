package assprac66;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class assprac666 extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
       
        boolean isNewSession = true;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("sessionId")) {
                    isNewSession = false;
                    break;
                }
            }
        }
        
  
        if (isNewSession) {
            String sessionId = java.util.UUID.randomUUID().toString();
            Cookie sessionCookie = new Cookie("sessionId", sessionId);
            response.addCookie(sessionCookie);
            out.println("New session created. Session ID: " + sessionId);
        } else {
            out.println("Existing session found. Session ID: " + getSessionId(cookies));
        }
    }
    
    private String getSessionId(Cookie[] cookies) {
        for (Cookie cookie : cookies) {
            if (cookie.getName().equals("sessionId")) {
                return cookie.getValue();
            }
        }
        return null;
    }
}