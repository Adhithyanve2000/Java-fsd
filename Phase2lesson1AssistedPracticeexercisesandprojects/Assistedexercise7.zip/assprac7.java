package sdsd;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class assprac7 extends HttpServlet {
    
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // Getting the current session ID
        String sessionId = request.getSession(true).getId();
        
        out.println("<html><body>");
        out.println("<h1>Session Tracking Example using URL Rewrite</h1>");

        // For each link, append the session ID as a query parameter
        out.println("<a href=\"" + response.encodeURL("Page1Servlet?jsessionid=" + sessionId) + "\">Visit Page 1</a><br/>");
        out.println("<a href=\"" + response.encodeURL("Page2Servlet?jsessionid=" + sessionId) + "\">Visit Page 2</a><br/>");
        out.println("<a href=\"" + response.encodeURL("Page3Servlet?jsessionid=" + sessionId) + "\">Visit Page 3</a><br/>");
        
        out.println("</body></html>");
    }
}