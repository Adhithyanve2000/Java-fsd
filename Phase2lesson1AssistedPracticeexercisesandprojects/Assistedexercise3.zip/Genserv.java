package Prac;

import java.io.IOException;

import javax.servlet.ServletException;


/**
 * Servlet implementation class Genserv
 */
import javax.servlet.*;

import java.io.PrintWriter;

public class Genserv implements Servlet {

    private ServletConfig servletConfig;

    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
        this.servletConfig = servletConfig;
    }

    @Override
    public ServletConfig getServletConfig() {
        return servletConfig;
    }

    @Override
    public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
        // Set the content type of the response
        servletResponse.setContentType("text/html");

        // Get a PrintWriter object to write the response
        PrintWriter out = servletResponse.getWriter();

        // Write the response content
        out.println("<html><body>");
        out.println("<h1>Hello, Generic Servlet!</h1>");
        out.println("</body></html>");
    }

    @Override
    public String getServletInfo() {
        return "GenericDemoServlet";
    }

    @Override
    public void destroy() {
        // Clean up resources, if any
    }
}