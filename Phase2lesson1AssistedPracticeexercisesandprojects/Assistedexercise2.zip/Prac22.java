package sdsd;

import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;

public class Prac22 implements Servlet {

    private ServletConfig servletConfig;

    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
        this.servletConfig = servletConfig;
    }

    @Override
    public ServletConfig getServletConfig() {
        return servletConfig;
    }

    @Override
    public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
 
        servletResponse.setContentType("text/html");

   
        PrintWriter out = servletResponse.getWriter();

        out.println("<html><body>");
        out.println("<h1>Hello, Generic Servlet!</h1>");
        out.println("</body></html>");
    }

    @Override
    public String getServletInfo() {
        return "GenericDemoServlet";
    }

    @Override
    public void destroy() {};
      
}
