package dssd;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/session")
public class assprac88 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(true);

        if (session.getAttribute("session_id") == null) {
            session.setAttribute("session_id", java.util.UUID.randomUUID().toString());
        }

        if (request.getParameter("session_id") != null) {
            
            session.setAttribute("session_id", request.getParameter("session_id"));
        }

  
        String sessionID = (String) session.getAttribute("session_id");

        response.setContentType("text/html");
        response.getWriter().println("<html><head><title>Session Tracking Demo</title></head><body>");
        response.getWriter().println("<h1>Session Tracking Demo</h1>");

        response.getWriter().println("<p>Session ID: " + sessionID + "</p>");
        response.getWriter().println("<form action=\"/session\" method=\"GET\">");
        response.getWriter().println("<input type=\"hidden\" name=\"session_id\" value=\"" + sessionID + "\">");
        response.getWriter().println("<input type=\"submit\" value=\"Update Session ID\">");
        response.getWriter().println("</form>");

        response.getWriter().println("</body></html>");
    }
}