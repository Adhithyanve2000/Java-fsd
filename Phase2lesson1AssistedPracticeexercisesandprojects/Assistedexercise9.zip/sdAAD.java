package assprac9sdsd;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

public class sdAAD extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

    
        HttpSession session = request.getSession();


        boolean isNewSession = session.isNew();

 
        String sessionId = session.getId();

        session.setAttribute("username", "John");
        session.setAttribute("email", "john@example.com");

        out.println("<html><body>");

        if (isNewSession) {
            out.println("<h1>New session created with ID: " + sessionId + "</h1>");
        } else {
            out.println("<h1>Existing session found with ID: " + sessionId + "</h1>");
            out.println("<h2>Session attributes:</h2>");
            out.println("<p>Username: " + session.getAttribute("username") + "</p>");
            out.println("<p>Email: " + session.getAttribute("email") + "</p>");
        }

        out.println("</body></html>");
    }
}