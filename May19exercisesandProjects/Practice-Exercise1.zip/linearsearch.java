package assisted;


import java.util.Scanner;
public class linearsearch
{	    
	public static int linearsearch1(int[] arr, int target) {
	
	        for (int i = 0; i < arr.length; i++) {
	            if (arr[i] == target) {
	                return i; // Return the index where the target is found
	            }
	        }
	        return -1; // Return -1 if the target is not found
	    }

	    public static void main(String[] args) {
	    	  int[] numbers = new int[10];
	          Scanner scanner = new Scanner(System.in);
	    	 System.out.println("Enter 10 numbers:");
	         for (int i = 0; i < numbers.length; i++) {
	             numbers[i] = scanner.nextInt();
	         }

	         System.out.print("Enter the target value to search: ");
	         int target = scanner.nextInt();


	        int index = linearsearch1(numbers, target);

	        if (index != -1) {
	            System.out.println("Target found at index: " + index);
	        } else {
	            System.out.println("Target not found");
	        }
	        scanner.close();
	    }
	  
	}

