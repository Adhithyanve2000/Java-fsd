package assisted;




	import java.util.Arrays;

	public class expsearch {

	    public static int exponentialSearch(int[] arr, int target) {
	        int size = arr.length;

	        if (arr[0] == target)
	            return 0;

	        int bound = 1;
	        while (bound < size && arr[bound] <= target)
	            bound *= 2;

	        int left = bound / 2;
	        int right = Math.min(bound, size - 1);

	        return binarySearch(arr, target, left, right);
	    }

	    public static int binarySearch(int[] arr, int target, int left, int right) {
	        if (right >= left) {
	            int mid = left + (right - left) / 2;

	            if (arr[mid] == target)
	                return mid;

	            if (arr[mid] > target)
	                return binarySearch(arr, target, left, mid - 1);

	            return binarySearch(arr, target, mid + 1, right);
	        }

	        return -1;
	    }

	    public static void main(String[] args) {
	        int[] arr = {5, 9, 2, 7, 1, 6, 3};
	        int target = 6;


	        Arrays.sort(arr);

	        int index = exponentialSearch(arr, target);

	        if (index != -1) {
	            System.out.println("Target found at index: " + index);
	        } else {
	            System.out.println("Target not found");
	        }
	    }
	}
