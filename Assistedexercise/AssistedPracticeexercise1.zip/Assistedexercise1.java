package AssistedExercises2;


class MyThread extends Thread {
 public void run() {
     System.out.println("Thread created by extending Thread class.");
 }
}


class MyRunnable implements Runnable {
 public void run() {
     System.out.println("Thread created by implementing Runnable interface.");
 }
}

public class Assistedexercise1{
 public static void main(String[] args) {
     
     MyThread t1 = new MyThread();
     t1.start();
     MyRunnable r1 = new MyRunnable();
     Thread t2 = new Thread(r1);
     t2.start();
 }
}



