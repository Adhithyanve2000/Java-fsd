package AssistedExercises2;
import java.util.Scanner;

public class Exceptionexercise{


	
	    
	
	    static class MyException extends Exception {
	        public MyException(String message) {
	            super(message);
	        }
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter a number between 1 and 10: ");
	        int num = scanner.nextInt();

	        try {
	            if (num < 1 || num > 10) {
	               
	                throw new MyException("Number out of range");
	            } else if (num % 2 == 0) {
	               
	                throw new Exception("Even number");
	            } else {
	                System.out.println("Number is odd and in range");
	            }
	        } catch (MyException e) {
	            
	            System.out.println("Custom exception caught: " + e.getMessage());
	        } catch (Exception e) {
	            
	            System.out.println("Exception caught: " + e.getMessage());
	        } finally {
	            System.out.println("Finally block executed");
	        }
	    }
	}

