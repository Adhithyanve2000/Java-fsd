package ssd;

	interface A {
	    default void show() {
	        System.out.println("A");
	    }
	}

	// Interface B
	interface B {
	    default void show() {
	        System.out.println("B");
	    }
	}

	// Class C that implements both interfaces A and B
	class C implements A, B {
	    // Resolving the diamond problem by providing an implementation of the common method
	    public void show() {
	        A.super.show(); // Using the default implementation of show() in interface A
	    }
	}


	public class Daimond 
 {
	    public static void main(String[] args) {
	        C c = new C();
	        c.show(); // 
	    }
	}

