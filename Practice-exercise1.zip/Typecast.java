package AssistedPractice1;

public class Typecast {
	public static void main(String[] args) {
        //Implicit type casting
        int x = 11;
        double y = x;
        System.out.println("x = " + x);
        System.out.println("y = " + y);

        //Explicit type casting
        double a = 3.18;
        int b = (int) a;
        System.out.println("a = " + a);
        System.out.println("b = " + b);
    }
}


