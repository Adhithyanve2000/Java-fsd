package puthiyaprojectpuyi;

import java.util.Scanner;

public class rotatearrayy{
	
	



		
		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);

		        System.out.print("Enter the number of elements in the array: ");
		        int length = scanner.nextInt();

		        int[] array = new int[length];
		        System.out.println("Enter the elements of the array:");

		        for (int i = 0; i < length; i++) {
		            array[i] = scanner.nextInt();
		        }

		        System.out.print("Enter the number of steps to right rotate: ");
		        int rotationSteps = scanner.nextInt();

		        System.out.println("Original Array:");
		        printArray(array);

		        rightRotateArray(array, rotationSteps);

		        System.out.println("Array after right rotation:");
		        printArray(array);

		        scanner.close();
		    }

		    public static void rightRotateArray(int[] array, int steps) {
		        int length = array.length;
		        int[] rotatedArray = new int[length];

		        for (int i = 0; i < length; i++) {
		            int newPosition = (i + steps) % length;
		            rotatedArray[newPosition] = array[i];
		        }

		        System.arraycopy(rotatedArray, 0, array, 0, length);
		    }

		    public static void printArray(int[] array) {
		        for (int num : array) {
		            System.out.print(num + " ");
		        }
		        System.out.println();
		    }
		}



