package puthiyaprojectpuyi;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

	
		public class Fourthsmallestnumber {

		    public static int findFourthSmallest(List<Integer> numbers) {
		        if (numbers == null || numbers.size() < 4) {
		            throw new IllegalArgumentException("List should contain at least 4 elements.");
		        }

		        List<Integer> sortedList = new ArrayList<>(numbers);
		        Collections.sort(sortedList);

		        return sortedList.get(3); // Fourth smallest element is at index 3
		    }

		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);

		        System.out.print("Enter the number of elements in the list: ");
		        int length = scanner.nextInt();

		        System.out.println("Enter the elements of the list:");

		        List<Integer> numbers = new ArrayList<>();
		        for (int i = 0; i < length; i++) {
		            numbers.add(scanner.nextInt());
		        }

		        int fourthSmallest = findFourthSmallest(numbers);
		        System.out.println("Fourth smallest element: " + fourthSmallest);

		        scanner.close();
		    }
	}
