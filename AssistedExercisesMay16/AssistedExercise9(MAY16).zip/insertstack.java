package puthiyaprojectpuyi;

public class insertstack {

}
