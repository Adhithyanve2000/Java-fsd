package puthiyaprojectpuyi;


	import java.util.Scanner;

	public class MultiplyMatrices {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter the number of rows of the first matrix: ");
	        int rowsA = scanner.nextInt();

	        System.out.print("Enter the number of columns of the first matrix: ");
	        int colsA = scanner.nextInt();

	        System.out.print("Enter the number of rows of the second matrix: ");
	        int rowsB = scanner.nextInt();

	        System.out.print("Enter the number of columns of the second matrix: ");
	        int colsB = scanner.nextInt();

	        if (colsA != rowsB) {
	            System.out.println("Matrix multiplication is not possible.");
	            return;
	        }

	        int[][] matrixA = new int[rowsA][colsA];
	        int[][] matrixB = new int[rowsB][colsB];

	        System.out.println("Enter the elements of the first matrix:");
	        for (int i = 0; i < rowsA; i++) {
	            for (int j = 0; j < colsA; j++) {
	                matrixA[i][j] = scanner.nextInt();
	            }
	        }

	        System.out.println("Enter the elements of the second matrix:");
	        for (int i = 0; i < rowsB; i++) {
	            for (int j = 0; j < colsB; j++) {
	                matrixB[i][j] = scanner.nextInt();
	            }
	        }

	        int[][] result = multiplyMatrices(matrixA, matrixB);

	        System.out.println("Resultant matrix after multiplication:");
	        printMatrix(result);

	        scanner.close();
	    }

	    public static int[][] multiplyMatrices(int[][] matrixA, int[][] matrixB) {
	        int rowsA = matrixA.length;
	        int colsA = matrixA[0].length;
	        int colsB = matrixB[0].length;

	        int[][] result = new int[rowsA][colsB];

	        for (int i = 0; i < rowsA; i++) {
	            for (int j = 0; j < colsB; j++) {
	                for (int k = 0; k < colsA; k++) {
	                    result[i][j] += matrixA[i][k] * matrixB[k][j];
	                }
	            }
	        }

	        return result;
	    }

	    public static void printMatrix(int[][] matrix) {
	        for (int[] row : matrix) {
	            for (int num : row) {
	                System.out.print(num + " ");
	            }
	            System.out.println();
	        }
	    }
	}

