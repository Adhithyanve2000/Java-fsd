package puthiyaprojectpuyi;


	import java.util.Scanner;

	class Node {
	    int data;
	    Node next;

	    public Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

	class LinkedList {
	    Node head;

	    public LinkedList() {
	        this.head = null;
	    }

	    public void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node current = head;
	            while (current.next != null) {
	                current = current.next;
	            }
	            current.next = newNode;
	        }
	    }

	    public void display() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }

	    public void deleteFirstOccurrence(int key) {
	        if (head == null) {
	            System.out.println("Linked list is empty.");
	            return;
	        }

	        if (head.data == key) {
	            head = head.next;
	            System.out.println("Deleted the first occurrence of " + key + ".");
	            return;
	        }

	        Node prev = null;
	        Node current = head;

	        while (current != null && current.data != key) {
	            prev = current;
	            current = current.next;
	        }

	        if (current == null) {
	            System.out.println("Key not found in the linked list.");
	            return;
	        }

	        prev.next = current.next;
	        System.out.println("Deleted the first occurrence of " + key + ".");
	    }
	}

	public class firstoccur  {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        LinkedList linkedList = new LinkedList();

	        System.out.print("Enter the number of elements in the linked list: ");
	        int n = scanner.nextInt();

	        for (int i = 0; i < n; i++) {
	            System.out.print("Enter element " + (i + 1) + ": ");
	            int value = scanner.nextInt();
	            linkedList.insert(value);
	        }

	        System.out.print("Enter the key to delete: ");
	        int key = scanner.nextInt();

	        System.out.println("Linked List before deletion:");
	        linkedList.display();

	        linkedList.deleteFirstOccurrence(key);

	        System.out.println("Linked List after deletion:");
	        linkedList.display();

	        scanner.close();
	    }
	}