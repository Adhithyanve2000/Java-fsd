package puthiyaprojectpuyi;


	import java.util.Scanner;
	import java.util.Stack;

	public class stackqueue {
	    public static void main(String[] args) {
	        Stack<Integer> stack = new Stack<>();
	        Scanner scanner = new Scanner(System.in);

	        while (true) {
	            System.out.println("1. Insert element");
	            System.out.println("2. Remove element");
	            System.out.println("3. Quit");
	            System.out.print("Enter your choice: ");
	            int choice = scanner.nextInt();

	            switch (choice) {
	                case 1:
	                    System.out.print("Enter the element to insert: ");
	                    int element = scanner.nextInt();
	                    stack.push(element);
	                    System.out.println("Element " + element + " inserted into the stack.");
	                    break;
	                case 2:
	                    if (stack.isEmpty()) {
	                        System.out.println("Stack is empty. No elements to remove.");
	                    } else {
	                        int removedElement = stack.pop();
	                        System.out.println("Removed element: " + removedElement);
	                    }
	                    break;
	                case 3:
	                    System.out.println("Exiting program...");
	                    scanner.close();
	                    System.exit(0);
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	                    break;
	            }

	            System.out.println("Stack elements: " + stack);
	            System.out.println();
	        }
	    }
	}


