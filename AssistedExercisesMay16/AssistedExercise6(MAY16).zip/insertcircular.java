package puthiyaprojectpuyi;

import java.util.Scanner;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    Node head;

    public SortedCircularLinkedList() {
        head = null;
    }

    public void insert(int value) {
        Node newNode = new Node(value);
        if (head == null) {
            head = newNode;
            newNode.next = newNode;
        } else if (value <= head.data) {
            Node last = getLastNode();
            newNode.next = head;
            head = newNode;
            last.next = head;
        } else {
            Node current = head;
            while (current.next != head && current.next.data < value) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public Node getLastNode() {
        Node current = head;
        while (current.next != head) {
            current = current.next;
        }
        return current;
    }

    public void display() {
        if (head == null) {
            System.out.println("Circular linked list is empty.");
            return;
        }
        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}

public class insertcircular{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SortedCircularLinkedList circularLinkedList = new SortedCircularLinkedList();

        System.out.print("Enter the number of elements in the circular linked list: ");
        int n = scanner.nextInt();

        for (int i = 0; i < n; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            int value = scanner.nextInt();
            circularLinkedList.insert(value);
        }

        System.out.print("Enter the element to insert: ");
        int element = scanner.nextInt();

        System.out.println("Circular Linked List before insertion:");
        circularLinkedList.display();

        circularLinkedList.insert(element);

        System.out.println("Circular Linked List after insertion:");
        circularLinkedList.display();

        scanner.close();
    }
}