package camerarental;
 
public class logindata{
	 private double walletAmount;
     private String username;
     private String password;
     
	    public logindata(String username, String password, double walletAmount) {
	        this.username = username;
	        this.password = password;
	        this.walletAmount = walletAmount;
	    }

	    public double getWalletAmount() {
	        return walletAmount;
	    }

	    public void deposit(double amount) {
	        walletAmount += amount;
	    }

	    public boolean hasSufficientBalance(double amount) {
	        return walletAmount >= amount;
	    }

	    public void deductAmount(double amount) {
	        walletAmount -= amount;
	    }
	    public boolean authenticate(String username, String password) {
	        return this.username.equalsIgnoreCase(username) && this.password.equals(password);
	    }
	}