package camerarental;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.Comparator;

public class mainpage {
	private List<Cameras> cameraList;
    private logindata user;
    private List<logindata> userList;
    private Scanner scanner;
    private String username;
    private String password;

    public mainpage() {
        cameraList = new ArrayList<>();
    
        scanner = new Scanner(System.in);
    }

    public void run() {
    	 displayWelcomeScreen();
    	authenticateUser();
       
        listofcameras();
        while (true) {
            displayMainMenu();
            int choice = getUserChoice();
            
            try {
                switch (choice) {
                    case 1:
                        addCamera();
                        break;
                    case 2:
                        rentCamera(userList);
                        break;
                    case 3:
                        manageWallet(user);
                        break;
                    case 4:
                        displayCameraList();
                        break;
                    case 5:
                        System.out.println("Closing the application...");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // Clear the input buffer
            }
            }
        }
    
    private void authenticateUser() {
        System.out.println("=================================");
        System.out.println("        AUTHENTICATION");
        System.out.println("=================================");

        userList = new ArrayList<>();
        userList.add(new logindata("John", "password123", 100.0));
        userList.add(new logindata("Serena", "password321", 99));
        userList.add(new logindata("Bhagat", "password321", 500));
        userList.add(new logindata("Malena", "password321", 500));

        while (true) {
            System.out.print("Enter your username: ");
            username = scanner.nextLine();
            System.out.print("Enter your password: ");
            password = scanner.nextLine();

            boolean isAuthenticated = false;
            for (logindata user : userList) {
                if (user.authenticate(username, password)) {
                    isAuthenticated = true;
                    break;
                }
            }

            if (isAuthenticated) {
                System.out.println("Authentication successful.");
                break;
            } else {
                System.out.println("Authentication failed. Please try again.");
            }
        }
    }
    private void displayWelcomeScreen() {
        System.out.println("=================================");
        System.out.println("  Welcome to Camera Rental App");
        System.out.println("=================================");
        System.out.println("Developer:Adhithyan V");
        System.out.println("=================================");
        System.out.println();
    }

    private void displayMainMenu() {
        System.out.println("=================================");
        System.out.println("          MAIN MENU");
        System.out.println("=================================");
        System.out.println("1. Add a camera");
        System.out.println("2. Rent a camera");
        System.out.println("3. Manage wallet");
        System.out.println("4. Display camera list");
        System.out.println("5. Exit");
        System.out.println();
        System.out.print("Enter your choice: ");
    }

    private int getUserChoice() {
    	
    	    try {
    	        return scanner.nextInt();
    	    } catch (InputMismatchException e) {
    	        System.out.println("Invalid input. Please enter a valid integer.");
    	        scanner.nextLine(); 
    	        return getUserChoice(); 
    	    }
    	
    }
   private void listofcameras()
   {
	cameraList.add(new Cameras("Nikon", "DX-300",55));
	cameraList.add(new Cameras("Fujifilm", "DX-500",65));
	cameraList.add(new Cameras("Sony", "HG-300",75));
	cameraList.add(new Cameras("Hitachi", "RTX-1800",105));
	cameraList.add(new Cameras("Fujifilm", "WE-900",45));
	cameraList.add(new Cameras("Panasonic", "OP-X00",85));
	cameraList.add(new Cameras("Samsung", "GPT-400",75));
	cameraList.add(new Cameras("Sony", "HAL-100",95));
	cameraList.add(new Cameras("Canon", "RDX-300",50));
	
   }
    private void addCamera() {
        System.out.println("=================================");
        System.out.println("         ADD A CAMERA");
        System.out.println("=================================");
        System.out.print("Enter the brand: ");
        String brand = scanner.nextLine();
        System.out.print("Enter the model: ");
        String model = scanner.nextLine();
        System.out.print("Enter the per-day rental amount: ");
        double rentalAmount = scanner.nextDouble();

        Cameras camera = new Cameras(brand, model, rentalAmount);
        cameraList.add(camera);

        System.out.println("Camera added successfully.");
        System.out.println();
    }
   
    private void rentCamera(List<logindata> userList) {
        System.out.println("=================================");
        System.out.println("        RENT A CAMERA");
        System.out.println("=================================");

        if (cameraList.isEmpty()) {
            System.out.println("No cameras available for rent.");
            System.out.println();
            return;
        }

        displayCameraList();

        System.out.print("Enter the index of the camera to rent:");
        int index = scanner.nextInt();

        if (index >= 0 && index < cameraList.size()) {
            Cameras camera = cameraList.get(index);

    
            boolean isAuthenticated = false;
            logindata user = null;
            for (logindata userData : userList) {
                if (userData.authenticate(username, password)) {
                    isAuthenticated = true;
                    user = userData;
                    break;
                }
            }
            if (isAuthenticated) {
                if (user.hasSufficientBalance(camera.getRentalAmount())) {
                    user.deductAmount(camera.getRentalAmount());
                    System.out.println(camera.getBrand()+camera.getModel()+"\trented successfully.");
                } else {
                    System.out.println("Insufficient wallet amount to rent the camera.");
                }
            } else {
                System.out.println("Authentication failed. Please try again.");
            }
        } else {
            System.out.println("Invalid camera index.");
        }

        System.out.println();
    }

    private void manageWallet(logindata user) {
        System.out.println("=================================");
        System.out.println("        MANAGE WALLET");
        System.out.println("=================================");
        System.out.println("1. View wallet amount");
        System.out.println("2. Add money to the wallet");
        System.out.println("3. Go back to the main menu");
        System.out.println();
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                boolean isAuthenticated = false;
                for (logindata userData : userList) {
                    if (userData.authenticate(username, password)) {
                        isAuthenticated = true;
                        user = userData;
                        break;
                    }
                }
                if (isAuthenticated) {
                    System.out.println("Wallet amount: $" + user.getWalletAmount());
                } else {
                    System.out.println("Authentication failed. Please try again.");
                }
                break;
            case 2:
                isAuthenticated = false;
                for (logindata userData : userList) {
                    if (userData.authenticate(username, password)) {
                        isAuthenticated = true;
                        user = userData;
                        break;
                    }
                }
                if (isAuthenticated) {
                    System.out.print("Enter the amount to deposit: ");
                    double amount = scanner.nextDouble();
                    scanner.nextLine();
                    user.deposit(amount);
                    System.out.println("Amount deposited successfully.");
                } else {
                    System.out.println("Authentication failed. Please try again.");
                }
                break;
            case 3:
                return;
            default:
                System.out.println("Invalid choice.");
        }

        System.out.println();
    }

    private void displayCameraList() {
        System.out.println("=================================");
        System.out.println("     AVAILABLE CAMERA LIST");
        System.out.println("=================================");

        System.out.printf("%-6s %-15s %-15s %s\n", "Index", "Brand", "Model", "Rental Amount per Day ($)");
        if (cameraList.isEmpty()) {
            System.out.println("No cameras available.");
        } else {
            cameraList.sort(Comparator.comparing(Cameras::getBrand));

            for (int i = 0; i < cameraList.size(); i++) {
                Cameras camera = cameraList.get(i);
                System.out.printf("%-6d %-15s %-15s %.2f\n", i, camera.getBrand(), camera.getModel(), camera.getRentalAmount());
            }
        }

        System.out.println();
    }
}