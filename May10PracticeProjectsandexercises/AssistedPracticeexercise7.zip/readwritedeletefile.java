package AssistedExercises2;

import java.io.*;

public class readwritedeletefile {
	

	
	    public static void main(String[] args) {
	       
	        File file = new File("test.txt");
	        try {
	            file.createNewFile();
	            System.out.println("File created: " + file.getName());
	        } catch (IOException e) {
	            System.out.println("An error occurred while creating the file.");
	            e.printStackTrace();
	        }

	       
	        try {
	            FileWriter writer = new FileWriter(file);
	            writer.write("Hello, World!\n");
	            writer.write("This is a test.\n");
	            writer.close();
	            System.out.println("Data written to file.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while writing to the file.");
	            e.printStackTrace();
	        }

	    
	        try {
	            BufferedReader reader = new BufferedReader(new FileReader(file));
	            String line;
	            while ((line = reader.readLine()) != null) {
	                System.out.println(line);
	            }
	            reader.close();
	        } catch (IOException e) {
	            System.out.println("An error occurred while reading the file.");
	            e.printStackTrace();
	        }

	   
	        try {
	            FileWriter writer = new FileWriter(file, true);
	            writer.write("This is an update.\n");
	            writer.close();
	            System.out.println("File updated.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while updating the file.");
	            e.printStackTrace();
	        }

	        try {
	            if (file.delete()) {
	                System.out.println("File deleted: " + file.getName());
	            } else {
	                System.out.println("Failed to delete the file.");
	            }
	        } catch (Exception e) {
	            System.out.println("An error occurred while deleting the file.");
	            e.printStackTrace();
	        }
	    }
	}

