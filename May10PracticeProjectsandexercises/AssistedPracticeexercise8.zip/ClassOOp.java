package AssistedExercises2;

public class ClassOOp {
	
	    private int accountNumber;
	    private String accountHolderName;
	    private double balance;

	 
	    public BankAccount(int accountNumber, String accountHolderName, double balance) {
	        this.accountNumber = accountNumber;
	        this.accountHolderName = accountHolderName;
	        this.balance = balance;
	    }


	    public int getAccountNumber() {
	        return accountNumber;
	    }

	    public void setAccountNumber(int accountNumber) {
	        this.accountNumber = accountNumber;
	    }

	    public String getAccountHolderName() {
	        return accountHolderName;
	    }

	    public void setAccountHolderName(String accountHolderName) {
	        this.accountHolderName = accountHolderName;
	    }

	    public double getBalance() {
	        return balance;
	    }

	    public void setBalance(double balance) {
	        this.balance = balance;
	    }

	    public void deposit(double amount) {
	        balance += amount;
	    }

	    public void withdraw(double amount) {
	        if (balance >= amount) {
	            balance -= amount;
	        } else {
	            System.out.println("Insufficient balance");
	        }
	    }

	    public void displayAccountDetails() {
	        System.out.println("Account Number: " + accountNumber);
	        System.out.println("Account Holder Name: " + accountHolderName);
	        System.out.println("Balance: " + balance);
	    }
	}

	
	public class Main {
	    public static void main(String[] args) {
	        
	        BankAccount account1 = new BankAccount(123456, "John Doe", 1000);
	        BankAccount account2 = new BankAccount(789012, "Jane Smith", 5000);

	       
	        System.out.println("Account Number of account1: " + account1.getAccountNumber());
	        account1.setAccountHolderName("John Smith");
	        System.out.println("Account Holder Name of account1: " + account1.getAccountHolderName());

	        System.out.println("toString() method of account1: " + account1.toString());

	    
	        account1.deposit(500);
	        account2.withdraw(1000);

	   
	        account1.displayAccountDetails();
	        account2.displayAccountDetails();
	    }
	}

