package AssistedExercises2;

public class SleepWaitDemo {

    public static void main(String[] args) {
        Thread t1 = new Thread(() -> {
            try {
                System.out.println("Thread 1 is sleeping...");
                Thread.sleep(5000); // sleep for 5 seconds
                System.out.println("Thread 1 is awake.");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        Thread t2 = new Thread(() -> {
            synchronized (SleepWaitDemo.class) {
                try {
                    System.out.println("Thread 2 is waiting...");
                    SleepWaitDemo.class.wait(); // wait for notification
                    System.out.println("Thread 2 is awake.");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        t1.start();
        t2.start();

   
        try {
            Thread.sleep(3000);
            synchronized (SleepWaitDemo.class) {
                SleepWaitDemo.class.notify();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
