package AssistedPractice2;

public class Main {
	 public static void main(String[] args) {
	        MyClass obj = new MyClass();
	        System.out.println(obj.publicVar);
	        obj.publicMethod();

	
	    }
	}